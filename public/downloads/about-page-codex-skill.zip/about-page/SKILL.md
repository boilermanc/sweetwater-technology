---
name: about-page
description: Research, draft, implement, or review a company's About page so visitors can understand the organization and its claims are clear, verifiable, and accessible to search crawlers. Use for About/Our Story page work across websites; not for generic landing pages or unverified SEO promises.
---

# About page

Create an accurate, useful first-party explanation of an organization. Adapt the content to the company's audience, voice, business model, site architecture, and available evidence. The attached SOP that informed this skill is a reference framework, not a source of company facts or a guarantee of search or AI visibility.

## Establish the facts

- Inspect the project's repository guidance, site structure, existing About page, and relevant brand or product material before editing.
- Gather the official company name, domain, offering/category, audience, origin, people, location, pricing and terms, customer evidence, social profiles, and current URLs as relevant. Record where consequential claims came from. Ask for missing material only when it blocks a truthful result.
- Use only confirmed facts. Do not invent founders, dates, metrics, customers, prices, guarantees, reviews, competitor comparisons, or profile links. Omit unavailable facts or mark unresolved items clearly in a draft for review. Treat numbers and client names as claims requiring explicit evidence or approval before publishing.

## Shape the page

- Open with a plain, specific sentence saying what the organization is, what it does, and for whom. Make it natural for readers; third-person wording can help extraction but is not mandatory.
- Cover the relevant parts of this framework: offerings; meaningful differentiators; customer or user segments; team and origin; how the product or service works; concise key facts; and common questions. Choose the number, order, and headings based on the company and available facts. Do not pad sections to satisfy a fixed count.
- For each offering, explain what customers receive and the practical outcome. Distinguish factual differentiation from promotional claims. Name competitors only when the comparison is useful, accurate, authorized, and supportable.
- Present key facts in visible HTML text, using a table or definition list when that aids scanning. Include only applicable fields. Keep FAQ answers direct and consistent with the main page; do not repeat facts solely for keyword coverage.
- Link to relevant product, pricing, proof, contact, and conversion pages that exist. Write a distinct page title and description that accurately summarize the page; avoid rigid character limits when clarity suffers.

## Implement and verify

- Follow the site's framework and conventions. Make the main content available in the HTML response when feasible; check the rendered page and crawlable text. Use semantic headings, descriptive links, and accessible tables or lists.
- Use a self-referencing canonical when appropriate, and check status, robots directives, navigation links, and sitemap inclusion according to the site's publishing setup. Do not assume every project uses `/about`.
- Add structured data only when relevant to the actual page and supported by current search guidance. It must match visible, verified content. Organization markup may help identify the entity; select other schema types based on what the page actually describes. FAQPage markup is optional and does not imply Google will display FAQ rich results. Validate syntax and eligibility with the appropriate current tools; the Rich Results Test does not validate every schema type.
- Check factual consistency across prose, key facts, metadata, links, and structured data. Review mobile layout and accessibility. Report what was verified, what remains unconfirmed, and any deployment step requiring user authorization.

For the source SOP's field prompts, see [references/content-prompts.md](references/content-prompts.md). Use them selectively; they are prompts, not required claims or counts.
