# About page content prompts

Adapted from the user's 11-page “SOP: How to Build a Perfectly Optimized About Us Page.” These prompts support information gathering and drafting; none supplies facts about a particular company.

## Content inventory

| Area | Questions to answer when relevant |
| --- | --- |
| Entity | What is the official name? What category best describes the offering? What does it do, and for whom? |
| Offerings | What products or services are currently available? What does a customer receive? Which outcomes are evidenced? |
| Differentiation | What specific differences are supported by product behavior, terms, process, or reliable evidence? |
| Audience | Who actually uses it? Are industries, company sizes, or use cases confirmed? |
| Team and origin | Who founded or leads it? When and why did it start? Which biographies and profile links are approved? |
| Delivery | How do customers start, use, receive, or get support for the offering? What turnaround, channels, or integrations are documented? |
| Key facts | Which of name, type, year, location, website, offering, pricing, terms, scale, and social channels are public and current? |
| Questions | Which real customer questions can be answered clearly from confirmed information? |

## Source-specific cautions

- The source prescribes six services, five differentiators, eight sections, six FAQs, a `/about` URL, competitor names, and no em dashes. Treat these as examples or house-style preferences, not universal requirements.
- Its suggested customer counts, project totals, client logos, prices, and competitor lists are placeholders. Never copy them as facts.
- The source claims specific LLM citation, knowledge-graph, and ranking effects. Do not promise those outcomes. A clear, accessible page can help people and crawlers understand an organization, but indexing, citations, and rankings are not guaranteed.
- The source says FAQ markup produces rich results. Google's current guidance restricts FAQ rich results to well-known government and health sites. See [Google FAQPage guidance](https://developers.google.com/search/docs/appearance/structured-data/faqpage) and [Google's FAQ change announcement](https://developers.google.com/search/blog/2023/08/howto-faq-changes).
- E-E-A-T is not a numeric domain score or a specific ranking factor. See [Google's helpful content guidance](https://developers.google.com/search/docs/fundamentals/creating-helpful-content).
- Google can render JavaScript, though server-rendered or prerendered important content is often useful for users and crawlers. See [Google's JavaScript SEO guidance](https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics).
- For current structured-data fields and placement, use [Google's Organization guidance](https://developers.google.com/search/docs/appearance/structured-data/organization) and the relevant current type documentation. Do not copy the SOP's JSON-LD templates blindly.
